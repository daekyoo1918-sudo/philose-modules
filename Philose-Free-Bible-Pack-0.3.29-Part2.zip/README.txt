Philose Free Bible Pack

Version: 0.3.29
Part: 2/2
Philose > 자료 관리 > 모듈 파일 가져오기에서 이 ZIP을 선택하세요.
두 ZIP을 차례로 가져오면 전체 무료 성경이 설치됩니다.
